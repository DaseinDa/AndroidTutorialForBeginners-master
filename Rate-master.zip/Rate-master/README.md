# Rate
android查询汇率工具
项目中用到一些常用的控件比如侧滑返回，**recyclerview**下拉刷新，**listview**侧滑菜单等等，有兴趣的可以下载源码，写的比较仓促，有不足之处多多包含，(^_^)

![效果.gif](https://github.com/ldoublem/Rate/blob/master/app/gif/%E6%95%88%E6%9E%9C.gif?raw=true)
![效果.png](https://github.com/ldoublem/Rate/blob/master/app/gif/%E6%95%88%E6%9E%9C.png)
