package com.ldoublem.rate.baseActivity;

/**
 * Created by lumingmin on 16/5/22.
 */
public class G {
    public static final int DB_VISISON = 1;

    public static String HttpGetTpye = "http://apis.baidu.com/apistore/currencyservice/type";
    public static String HttpGetCurrency = "http://apis.baidu.com/apistore/currencyservice/currency";
    public static String Apikey="bd1cb93ef6d8105c69629e9569d707cb";
    public static String RefTag="RefTag";
    public static int RequestCodeByHome=1001;



}
